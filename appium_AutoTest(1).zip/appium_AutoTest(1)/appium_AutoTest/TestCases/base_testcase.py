# -*- coding:utf-8 -*-
# ! /usr/bin/python
"""
 @Describe:
 
 @File        :   base_testcase.py
 @Create_Time :   7/11/2019 3:29 AM
 @Author      :   Feng Qian

"""
from appium_AutoTest.PageObjects.login.login_page import LoginPage
from appium_AutoTest.conf.appium_case import AppiumCase
import unittest
class AppBaseTestCase(AppiumCase):
        def __init__(self,*args, **kwargs):
            unittest.TestCase.__init__(self, *args, **kwargs)
            self.login_page = LoginPage()