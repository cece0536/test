# -*- coding:utf-8 -*-
# ! /usr/bin/python
"""
 @Describe:
 
 @File        :   logout.py
 @Create_Time :   7/11/2019 3:26 AM
 @Author      :   Feng Qian

"""
from TestCases.base_testcase import AppBaseTestCase

class LoginTest(AppBaseTestCase):
    def test_logout(self):
        # 退出登录
        self.login_page.logout()
        self.assertFalse(self.login_page)



