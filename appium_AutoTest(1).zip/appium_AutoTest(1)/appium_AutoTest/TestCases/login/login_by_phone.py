# -*- coding:utf-8 -*-
# ! /usr/bin/python
"""
 @Describe:
 
 @File        :   login_by_phone.py
 @Create_Time :   7/11/2019 2:30 AM
 @Author      :   Feng Qian

"""
import time
from appium_AutoTest.TestCases.base_testcase import AppBaseTestCase


class LoginTest(AppBaseTestCase):

    def test_login_by_phone(self):
        # 点击登录
        self.login_page.get_login_panel()
        time.sleep(3)
        # 输入手机号和验证码
        self.login_page.input_phoneNumber("10000000003")
        self.login_page.input_code("123456")
        # 点击登录
        self.login_page.click_login()

        self.assertTrue(self.page.is_login())

    def test_logout(self):
        # 退出登录
        self.login_page.logout()
        self.assertFalse(self.login_page)




