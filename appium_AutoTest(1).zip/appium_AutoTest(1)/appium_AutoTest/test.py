import os
import sys
import importlib
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)),'TestCases','login'))
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)),'TestCases'))
logout = importlib.import_module("%s.%s"%("login","logout"))
module = logout.LoginTest()
print(sys.path)