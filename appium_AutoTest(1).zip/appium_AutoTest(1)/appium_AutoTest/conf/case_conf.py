# -*- coding:utf-8 -*-
# ! /usr/bin/python
"""
 @Describe:
    测试用例处理,打包
 @File        :   case_conf.py
 @Create_Time :   7/11/2019 4:15 AM
 @Author      :   Feng Qian

"""

import unittest
import importlib
import sys
from .path_conf import *

"""

:param cases: cases ={
"login":["login_by_phone.LoginTest.test_login_by_phone"]
}
"""

def load_all_cases(cases):
    suite = unittest.TestSuite()
    for key, item in cases.items():
        module_path = os.path.join(CASES_PATH, key)
        sys.path.insert(0, CASES_PATH)
        sys.path.insert(0, module_path)
        for case in item:
            case_path = case.split('.')
            module = importlib.import_module("%s.%s"%(key,case_path[0]))
            cls = getattr(module, case_path[1])
            suite.addTest(cls(case_path[-1]))
    return suite




