import os

BASE_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PAGE_PATH = os.path.join(BASE_PATH, "PageObjects")
CASES_PATH = os.path.join(BASE_PATH, "TestCases")
DATA_PATH = os.path.join(BASE_PATH, "TestDatas")
global DRIVER
DRIVER = []

def set_driver(new_driver):
    DRIVER.append(new_driver)

def get_driver():
    return DRIVER

