

import unittest
from .appium_driver import AppiumDriver
from appium_AutoTest.conf.path_conf import set_driver,DRIVER
class AppiumCase(unittest.TestCase):

    def __init__(self, *args, **kwargs):
        unittest.TestCase.__init__(self, *args, **kwargs)


    def setUp(self):
        pass

    def tearDown(self):
        pass