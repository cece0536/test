# -*- coding:utf-8 -*-
# ! /usr/bin/python
"""
 @Describe:
 
 @File        :   appium_driver.py
 @Create_Time :   7/11/2019 9:48 PM
 @Author      :   Feng Qian

"""
from appium import webdriver
import unittest
import os
import sys
from appium_AutoTest.conf.path_conf import DRIVER,set_driver


desired_caps = {
    'platformName': 'Android',
    'deviceName': '192.168.57.107:5555	',
    'platformVersion': '6.0',
    'appPackage': 'com.babycloud.hanju',
    'appActivity': 'ui.activity.HanjuHomeActivity'
}


class AppiumDriver(object):

    @classmethod
    def get_driver(cls):
        driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', desired_caps)
        driver.implicitly_wait(10)
        cls.driver = driver
        set_driver(cls.driver)
        return driver

