import json
import os

from selenium.webdriver.support.wait import WebDriverWait
from appium_AutoTest.conf.path_conf import DRIVER
class BasePage(object):
    def __init__(self):

        self.driver = DRIVER[-1]
        print(self.driver)

    @staticmethod
    def get_widget_dict(module_name):
        """
        获取当前页面的控件字典
        @return: dict
        """
        file_name = "%s_widgets.json"% module_name
        file_path = os.path.join(os.path.dirname(__file__),module_name, file_name)
        with open(file_path, 'r') as f:
            widget_dict = json.load(f)
        return widget_dict

    @staticmethod
    def get_element_center_location(element):
        """获取控件中心点"""
        center_x = element.location.get('x') + int(element.size['width'] / 2)
        center_y = element.location.get('y') + int(element.size['height'] / 2)
        center = [center_x, center_y]
        return center

    def long_press_element(self, element, duration=2000):
        """长按控件 默认2000ms"""
        center = self.get_element_center_location(element)
        return self.driver.tap(center, duration)

    def click_center(self, element):
        """点击控件中心点"""
        self.driver.tap(self.get_element_center_location(element))

    def wait_element_by_id(self, id, timeout=5):
        """
        使用id查找控件,等待时间默认5s
        @param id: id
        @param timeout: 等待时间
        @return: element
        """
        try:
            element = WebDriverWait(self.driver, timeout).until(
                lambda x: x.find_element_by_id(id)
            )
        except Exception:
            element = None
        return element

    def wait_element_by_name(self, name, timeout=5):
        """
        使用name属性查找控件,等待时间默认5s
        @param name name
        @param timeout: 等待时间
        @return: element
        """
        try:
            element = WebDriverWait(self.driver, timeout).until(
                lambda x: x.find_element_by_name(name)
            )
        except Exception:
            element = None
        return element

    def wait_element_by_link_text(self, text, timeout=5):
        """
        使用link_text属性查找控件,等待时间默认5s
        @param text: link_text
        @param timeout: 等待时间
        @return: element
        """
        try:
            element = WebDriverWait(self.driver, timeout).until(
                lambda x: x.find_element_by_link_text(text)
            )
        except Exception:
            element = None
        return element

    def wait_element_by_partial_link_text(self, partial_text, timeout=5):
        """
        使用link_text模糊查找控件,默认等待时间5s
        @param partial_text: partial_link_text
        @param timeout: 等待时间
        @return: element
        """
        try:
            element = WebDriverWait(self.driver, timeout).until(
                lambda x: x.find_element_by_partial_link_text(partial_text)
            )
        except Exception:
            element = None
        return element

    def wait_element_by_tag_name(self, tag_name, timeout=5):
        """
        使用tag_name查找控件,默认等待时间5s
        @param tag_name: tag_name
        @param timeout: 等待时间
        @return: element
        """
        try:
            element = WebDriverWait(self.driver, timeout).until(
                lambda x: x.find_element_by_tag_name(tag_name)
            )
        except Exception:
            element = None
        return element

    def wait_element_by_xpath(self, xpath, timeout=5):
        """
        使用xpath找控件,默认等待时间5s
        @param xpath: xpath
        @param timeout: 等待时间
        @return: element
        """
        try:
            element = WebDriverWait(self.driver, timeout).until(
                lambda x: x.find_element_by_xpath(xpath)
            )
        except Exception:
            element = None
        return element

    def wait_element_css_selector(self, css, timeout=5):
        """
        使用xpath找控件,默认等待时间5s
        @param css: css_selector
        @param timeout: 等待时间
        @return: element
        """
        try:
            element = WebDriverWait(self.driver, timeout).until(
                lambda x: x.find_element_by_css_selector(css)
            )
        except Exception:
            element = None
        return element

    def wait_element_by_accessibility_id(self, desc, timeout=5):
        """
        使用content-desc查找控件,等待时间默认5s
        @param desc: content-desc
        @param timeout: 等待时间
        @return: element
        """
        try:
            element = WebDriverWait(self.driver, timeout).until(
                lambda x: x.find_element_by_accessibility_id(desc)
            )
        except Exception:
            element = None
        return element

    def wait_elements_by_id(self, id, timeout=5):
        """
        使用id查找一组控件,等待时间默认5s
        @param id: id
        @param timeout: 等待时间
        @return: elements
        """
        try:
            elements = WebDriverWait(self.driver, timeout).until(
                lambda x: x.find_elements_by_id(id)
            )
        except Exception:
            elements = None
        return elements

    def wait_elements_by_name(self, name, timeout=5):
        """
        使用name属性查找一组控件,等待时间默认5s
        @param name name
        @param timeout: 等待时间
        @return: elements
        """
        try:
            elements = WebDriverWait(self.driver, timeout).until(
                lambda x: x.find_elements_by_name(name)
            )
        except Exception:
            elements = None
        return elements

    def wait_elements_by_link_text(self, text, timeout=5):
        """
        使用link_text属性查找一组控件,等待时间默认5s
        @param text: link_text
        @param timeout: 等待时间
        @return: elements
        """
        try:
            elements = WebDriverWait(self.driver, timeout).until(
                lambda x: x.find_elements_by_link_text(text)
            )
        except Exception:
            elements = None
        return elements

    def wait_elements_by_partial_link_text(self, partial_text, timeout=5):
        """
        使用link_text模糊查找一组控件,默认等待时间5s
        @param partial_text: partial_link_text
        @param timeout: 等待时间
        @return: elements
        """
        try:
            elements = WebDriverWait(self.driver, timeout).until(
                lambda x: x.find_elements_by_partial_link_text(partial_text)
            )
        except Exception:
            elements = None
        return elements

    def wait_elements_by_tag_name(self, tag_name, timeout=5):
        """
        使用tag_name查找一组控件,默认等待时间5s
        @param tag_name: tag_name
        @param timeout: 等待时间
        @return: elements
        """
        try:
            elements = WebDriverWait(self.driver, timeout).until(
                lambda x: x.find_elements_by_tag_name(tag_name)
            )
        except Exception:
            elements = None
        return elements

    def wait_elements_by_xpath(self, xpath, timeout=5):
        """
        使用xpath查找一组控件,默认等待时间5s
        @param xpath: xpath
        @param timeout: 等待时间
        @return: elements
        """
        try:
            elements = WebDriverWait(self.driver, timeout).until(
                lambda x: x.find_elements_by_xpath(xpath)
            )
        except Exception:
            elements = None
        return elements

    def wait_elements_css_selector(self, css, timeout=5):
        """
        使用xpath查找一组控件,默认等待时间5s
        @param css: css_selector
        @param timeout: 等待时间
        @return: element
        """
        try:
            elements = WebDriverWait(self.driver, timeout).until(
                lambda x: x.find_elements_by_css_selector(css)
            )
        except Exception:
            elements = None
        return elements

    def wait_elements_by_accessibility_id(self, desc, timeout=5):
        """
        使用content-desc查找一组控件,等待时间默认5s
        @param desc: content-desc
        @param timeout: 等待时间
        @return: element
        """
        try:
            elements = WebDriverWait(self.driver, timeout).until(
                lambda x: x.find_elements_by_accessibility_id(desc)
            )
        except Exception:
            elements = None
        return elements





