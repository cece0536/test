from appium_AutoTest.PageObjects.base_page import BasePage


class LoginPage(BasePage):

    def __init__(self):
        super(LoginPage, self).__init__()
        self.module_name = "login"
        self.widget_dict = self.get_widget_dict(self.module_name)

    # 点击我的按钮,点出登录面板
    def get_login_panel(self):
        print(type(self.widget_dict["widget_my_btn"]["id"]))
        self.wait_element_by_id(self.widget_dict["widget_my_btn"]["id"]).click()
        self.wait_element_by_id(self.widget_dict["widget_login_btn"]["id"]).click()

    #输入手机号
    def input_phoneNumber(self, phoneNumber):
        self.wait_element_by_id(self.widget_dict["widget_number_input"]["id"]).send_keys(phoneNumber)

    # 输入验证码
    def input_code(self, code):
        self.wait_element_by_id(self.widget_dict["widget_verification_code_input"]["id"]).send_keys(code)

    # 点击登录
    def click_login(self):
        self.wait_element_by_id(self.widget_dict["widget_login_btn_in_panel"]["id"]).click()

    # 退出登录
    def logout(self):
        self.wait_element_by_id(self.widget_dict["widget_my_btn"]["id"]).click()
        self.wait_element_by_id(self.widget_dict["widget_settings_btn"]["id"]).click()
        self.wait_element_by_id(self.widget_dict['widget_logout_btn']["id"]).click()

    # 判断是否登录
    def is_login(self):
        login_btn = self.wait_element_by_id(self.widget_dict["widget_login_btn"]["id"])
        if login_btn:
            return False
        else:
            return True



